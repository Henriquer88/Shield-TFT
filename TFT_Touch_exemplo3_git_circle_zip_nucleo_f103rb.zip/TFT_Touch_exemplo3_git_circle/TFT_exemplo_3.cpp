// *******************************Henrique************************************//
//  Programa Teste 1 - Criando Formas Geométricas
//
// ************** Display TFT-  ILI9341 ************** \\


//************************ Biblioteca *****************************************//
#include "mbed.h"
#include "Arduino.h"
#include <MCUFRIEND_kbv.h>
MCUFRIEND_kbv tft;

//****************************************************************************//

//***********************Orientação  Display**********************************//


uint8_t Orientation = 1;  

//****************************************************************************//



//***********************Tabela de Cores**************************************//
#define BLACK   0x0000
#define BLUE    0x001F
#define RED     0xF800
#define GREEN   0x07E0
#define CYAN    0x07FF
#define MAGENTA 0xF81F
#define YELLOW  0xFFE0
#define WHITE   0xFFFF

//****************************************************************************//

//***********************Escrita no  Display**********************************//
void forma ()
{

    tft.drawTriangle(110, 150, 150, 100, 200, 150, WHITE); 
     //tft.drawTriangle(
    //tft.fillCircle(150,110,80,WHITE);
    tft.setTextColor(RED);
    tft.setTextSize(3);
    tft.setCursor(95, 98); // Orientação X,Y
    tft.println("TRIANGLE");


}

//****************************************************************************//



void setup(void)
{

    tft.reset();
    tft.begin();
    tft.setRotation(Orientation);
    tft.fillScreen(BLACK);  // Fundo do Display
    forma();
    delay(1000);
}

void loop()
{

}

